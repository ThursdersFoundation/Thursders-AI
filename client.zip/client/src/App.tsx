import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/Navigation";
import Home from "@/pages/Home";
import Journal from "@/pages/Journal";
import About from "@/pages/About";
import Settings from "@/pages/Settings";
import Pricing from "@/pages/Pricing";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex h-screen w-full bg-background overflow-hidden text-foreground">
      <Navigation />
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full relative overflow-hidden md:ml-64 pt-16 md:pt-0">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/journal" component={Journal} />
          <Route path="/about" component={About} />
          <Route path="/settings" component={Settings} />
          <Route path="/pricing" component={Pricing} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
