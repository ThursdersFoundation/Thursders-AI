import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, Search } from "lucide-react";
import { Message, useChat } from "@/hooks/use-chat";
import { MessageBubble } from "@/components/MessageBubble";
import { SearchPanel } from "@/components/SearchPanel";
import { nanoid } from "nanoid";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useCreateJournal } from "@/hooks/use-journals";

interface MessageWithSearch extends Message {
  searchData?: {
    mainKeyword: string;
    supportingKeywords: string[];
    searchQueries: string[];
    confidence: "Low" | "Medium" | "High";
  };
}

export default function Home() {
  const [input, setInput] = useState("");
  const [searchMode, setSearchMode] = useState(false);
  const [messages, setMessages] = useState<MessageWithSearch[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hello. I am Thursders AI. I'm here to help you learn, reflect, and grow. What's on your mind today?",
      timestamp: Date.now(),
    },
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { mutate: sendMessage, isPending } = useChat();
  const { mutate: saveJournal } = useCreateJournal();
  const { toast } = useToast();

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isPending) return;

    const userMsg: MessageWithSearch = {
      id: nanoid(),
      role: "user",
      content: input,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");

    sendMessage(
      { message: userMsg.content, mode: searchMode ? "SEARCH" : "GENERAL" },
      {
        onSuccess: (data) => {
          const aiMsg: MessageWithSearch = {
            id: nanoid(),
            role: "assistant",
            content: data.message,
            timestamp: Date.now(),
            searchData: data.searchData,
          };
          setMessages((prev) => [...prev, aiMsg]);

          // Handle special actions
          if (data.action === "SAVE_JOURNAL" && data.data) {
             saveJournal({
               content: data.data.summary || "Journal Entry",
               responses: data.data,
             }, {
               onSuccess: () => {
                 toast({ 
                   title: "Journal Saved", 
                   description: "Your reflection has been added to your journal.",
                 });
               }
             });
          }
        },
        onError: () => {
          toast({
            title: "Error",
            description: "Failed to get a response. Please try again.",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="flex flex-col h-full relative">
      {/* Header Area */}
      <div className="sticky top-0 z-10 p-6 bg-background/80 backdrop-blur-md border-b border-white/5 md:hidden">
        {/* Mobile header handled in Navigation layout wrapper, but we keep this for spacing if needed */}
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
        <div className="max-w-3xl mx-auto w-full">
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <div key={msg.id}>
                <MessageBubble role={msg.role} content={msg.content} />
                {msg.searchData && msg.role === "assistant" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="max-w-3xl mx-auto w-full"
                  >
                    <SearchPanel {...msg.searchData} />
                  </motion.div>
                )}
              </div>
            ))}
          </AnimatePresence>
          
          {isPending && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="flex items-center space-x-2 text-muted-foreground ml-12 text-sm"
            >
              <Sparkles className="w-4 h-4 animate-pulse text-primary" />
              <span>Thinking...</span>
            </motion.div>
          )}
          <div ref={messagesEndRef} className="h-4" />
        </div>
      </div>

      {/* Input Area */}
      <div className="p-4 md:p-6 bg-background/80 backdrop-blur-lg border-t border-white/5">
        <div className="max-w-3xl mx-auto w-full relative">
          <form onSubmit={handleSubmit} className="relative group">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={searchMode ? "What would you like to search for?" : "Ask a question, start a journal, or seek advice..."}
              className="w-full bg-secondary/50 border border-border rounded-xl px-5 py-4 pr-24 text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all duration-300 shadow-lg shadow-black/20"
              disabled={isPending}
              data-testid="input-chat-message"
            />
            
            {/* Mode Toggle Button */}
            <button
              type="button"
              onClick={() => setSearchMode(!searchMode)}
              className={`absolute right-14 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-all ${
                searchMode
                  ? "bg-primary/80 text-primary-foreground shadow-md shadow-primary/25"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
              title="Toggle Search Mode"
              data-testid="button-toggle-search-mode"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Send Button */}
            <button
              type="submit"
              disabled={!input.trim() || isPending}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-md shadow-primary/25 hover:shadow-lg hover:shadow-primary/30"
              data-testid="button-send-message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <p className="text-center text-xs text-muted-foreground mt-3 font-medium opacity-60">
            {searchMode 
              ? "Search Mode: I'll help you find accurate information with targeted keywords and queries."
              : "Thursders AI can make mistakes. Consider checking important information."}
          </p>
        </div>
      </div>
    </div>
  );
}
