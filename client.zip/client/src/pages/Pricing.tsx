import { motion } from "framer-motion";
import { Check, Zap } from "lucide-react";

export default function Pricing() {
  const plans = [
    {
      name: "Free",
      price: "Free",
      description: "Perfect for exploring",
      features: [
        "Unlimited chat interactions",
        "Daily journaling (3 questions)",
        "Basic knowledge base",
        "Search mode assistance",
      ],
      cta: "Get Started",
      highlighted: false,
    },
    {
      name: "Premium",
      price: "$9.99",
      period: "/month",
      description: "For serious learners",
      features: [
        "Everything in Free",
        "Advanced search with history",
        "Export journal entries",
        "Custom knowledge uploads",
        "Priority support",
        "Offline functionality",
      ],
      cta: "Coming Soon",
      highlighted: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For organizations",
      features: [
        "Everything in Premium",
        "Team collaboration",
        "API access",
        "Custom integrations",
        "Dedicated support",
        "SLA guarantee",
      ],
      cta: "Contact Us",
      highlighted: false,
    },
  ];

  return (
    <div className="p-4 md:p-8 lg:p-12 max-w-6xl mx-auto w-full h-full overflow-y-auto pb-20">
      {/* Header */}
      <div className="text-center mb-16 space-y-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Simple, Transparent Pricing
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose the plan that works best for your learning journey.
          </p>
        </motion.div>
      </div>

      {/* Pricing Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        {plans.map((plan, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`rounded-2xl p-8 border transition-all duration-300 ${
              plan.highlighted
                ? "bg-gradient-to-br from-primary/20 to-primary/5 border-primary/40 ring-2 ring-primary/20 scale-105"
                : "bg-card border-border/50 hover:border-primary/30"
            }`}
          >
            {plan.highlighted && (
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-4 h-4 text-primary" />
                <span className="text-xs font-bold text-primary uppercase tracking-wider">
                  Most Popular
                </span>
              </div>
            )}

            <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
            <div className="mb-6">
              <span className="text-4xl font-bold">{plan.price}</span>
              {plan.period && (
                <span className="text-muted-foreground ml-2">{plan.period}</span>
              )}
            </div>
            <p className="text-muted-foreground mb-6 text-sm">{plan.description}</p>

            <button
              className={`w-full py-3 px-4 rounded-lg font-semibold mb-8 transition-all ${
                plan.highlighted
                  ? "bg-primary text-primary-foreground hover:bg-primary/90"
                  : "bg-secondary text-foreground hover:bg-secondary/80"
              }`}
            >
              {plan.cta}
            </button>

            <div className="space-y-3">
              {plan.features.map((feature, j) => (
                <div key={j} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-foreground">{feature}</span>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      {/* FAQ Section */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="bg-secondary/30 rounded-2xl p-8 md:p-12 border border-border/50"
      >
        <h2 className="text-2xl font-bold mb-8">Frequently Asked Questions</h2>
        <div className="space-y-6">
          {[
            {
              q: "Can I switch plans anytime?",
              a: "Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately.",
            },
            {
              q: "Is there a free trial for Premium?",
              a: "Yes, Premium users get a 14-day free trial. No credit card required.",
            },
            {
              q: "What happens when I cancel?",
              a: "Your data is retained for 30 days. You can reactivate anytime and get back to where you left off.",
            },
          ].map((item, i) => (
            <div key={i}>
              <h3 className="font-semibold mb-2 text-foreground">{item.q}</h3>
              <p className="text-muted-foreground text-sm">{item.a}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
