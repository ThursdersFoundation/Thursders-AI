import { motion } from "framer-motion";
import { Bell, Moon, Lock, Trash2, HelpCircle } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();
  const [darkMode, setDarkMode] = useState(true);

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated.",
    });
  };

  const handleClearData = () => {
    toast({
      title: "Data Cleared",
      description: "All local data has been cleared. Journals remain safe in your account.",
      variant: "destructive",
    });
  };

  const settings = [
    {
      icon: Moon,
      title: "Dark Mode",
      description: "Display the app in dark mode (optimized for learning)",
      action: (
        <button
          onClick={() => setDarkMode(!darkMode)}
          className={`px-4 py-2 rounded-lg font-medium transition-all ${
            darkMode
              ? "bg-primary text-primary-foreground"
              : "bg-secondary text-foreground"
          }`}
        >
          {darkMode ? "On" : "Off"}
        </button>
      ),
    },
    {
      icon: Bell,
      title: "Notifications",
      description: "Get reminders for daily journaling and learning goals",
      action: (
        <button className="px-4 py-2 rounded-lg bg-secondary text-foreground font-medium hover:bg-secondary/80 transition-all">
          Configure
        </button>
      ),
    },
    {
      icon: Lock,
      title: "Privacy & Security",
      description: "Manage your data, privacy settings, and security options",
      action: (
        <button className="px-4 py-2 rounded-lg bg-secondary text-foreground font-medium hover:bg-secondary/80 transition-all">
          Manage
        </button>
      ),
    },
    {
      icon: HelpCircle,
      title: "Help & Support",
      description: "Get help with using Thunders AI and troubleshoot issues",
      action: (
        <button className="px-4 py-2 rounded-lg bg-secondary text-foreground font-medium hover:bg-secondary/80 transition-all">
          Visit Help
        </button>
      ),
    },
  ];

  return (
    <div className="p-4 md:p-8 lg:p-12 max-w-4xl mx-auto w-full h-full overflow-y-auto pb-20">
      {/* Header */}
      <div className="mb-12">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-4xl font-bold mb-2">Settings</h1>
          <p className="text-muted-foreground">
            Customize your Thunders AI experience
          </p>
        </motion.div>
      </div>

      {/* Settings Grid */}
      <div className="space-y-4 mb-12">
        {settings.map((setting, i) => {
          const Icon = setting.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card border border-border/50 rounded-2xl p-6 hover:border-primary/30 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-start gap-4">
                  <div className="bg-secondary/50 w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-foreground">
                      {setting.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {setting.description}
                    </p>
                  </div>
                </div>
                <div className="flex-shrink-0">{setting.action}</div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Danger Zone */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-red-500/5 border border-red-500/20 rounded-2xl p-6"
      >
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-4">
            <div className="bg-red-500/10 w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0">
              <Trash2 className="w-6 h-6 text-red-500" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-red-500">Clear Local Data</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Remove cached data and preferences. Your journal entries are safe and remain in your account.
              </p>
            </div>
          </div>
          <button
            onClick={handleClearData}
            className="flex-shrink-0 px-4 py-2 rounded-lg bg-red-500/20 text-red-400 font-medium hover:bg-red-500/30 transition-all border border-red-500/30"
          >
            Clear
          </button>
        </div>
      </motion.div>

      {/* Info Footer */}
      <div className="mt-12 pt-8 border-t border-border/50">
        <p className="text-xs text-muted-foreground text-center">
          Thunders AI v1.0 • Built for learning, thinking, and growing
        </p>
      </div>
    </div>
  );
}
