import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, Search } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface SearchPanelProps {
  mainKeyword: string;
  supportingKeywords: string[];
  searchQueries: string[];
  confidence: "Low" | "Medium" | "High";
}

export function SearchPanel({
  mainKeyword,
  supportingKeywords,
  searchQueries,
  confidence,
}: SearchPanelProps) {
  const { toast } = useToast();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const confidenceColor = {
    Low: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
    Medium: "bg-blue-500/20 text-blue-300 border-blue-500/30",
    High: "bg-green-500/20 text-green-300 border-green-500/30",
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    toast({
      title: "Copied",
      description: "Search query copied to clipboard",
      duration: 2000,
    });
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <Card className="p-5 bg-secondary/30 border-primary/20 mt-4">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Search Assistant</h3>
          </div>
          <Badge variant="outline" className={confidenceColor[confidence]}>
            {confidence} Confidence
          </Badge>
        </div>

        {/* Main Keyword */}
        <div>
          <p className="text-xs font-medium text-muted-foreground mb-1.5">
            Main Keyword
          </p>
          <div className="bg-background/50 rounded-lg px-3 py-2 border border-border">
            <p className="text-sm text-foreground font-medium">{mainKeyword}</p>
          </div>
        </div>

        {/* Supporting Keywords */}
        <div>
          <p className="text-xs font-medium text-muted-foreground mb-2">
            Supporting Keywords
          </p>
          <div className="flex flex-wrap gap-2">
            {supportingKeywords.map((keyword, idx) => (
              <Badge
                key={idx}
                variant="secondary"
                className="bg-primary/15 text-primary border-primary/30 text-xs"
              >
                {keyword}
              </Badge>
            ))}
          </div>
        </div>

        {/* Search Queries */}
        <div>
          <p className="text-xs font-medium text-muted-foreground mb-2">
            Search Ready Queries
          </p>
          <div className="space-y-2">
            {searchQueries.map((query, idx) => (
              <div
                key={idx}
                className="bg-background/50 rounded-lg px-3 py-2 border border-border flex items-center justify-between group hover:border-primary/40 transition-colors"
              >
                <p className="text-xs text-foreground font-mono break-words flex-1">
                  {query}
                </p>
                <button
                  onClick={() => handleCopy(query, idx)}
                  className="ml-2 p-1.5 rounded text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors opacity-0 group-hover:opacity-100"
                  title="Copy query"
                  data-testid={`button-copy-query-${idx}`}
                >
                  {copiedIndex === idx ? (
                    <span className="text-xs font-medium">✓</span>
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <p className="text-xs text-muted-foreground pt-2 border-t border-border/50">
          💡 <strong>Search Tip:</strong> Use these queries on Google, academic
          databases, or your preferred search engine for the most relevant results.
        </p>
      </div>
    </Card>
  );
}
