import { Link, useLocation } from "wouter";
import { Home, BookOpen, User, Menu, X, Settings, DollarSign } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import thundersLogo from "@assets/ChatGPT_Image_Mar_11,_2026,_02_13_35_AM_1773220514988.png";

export function Navigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const mainLinks = [
    { href: "/", label: "Chat", icon: Home },
    { href: "/journal", label: "Journal", icon: BookOpen },
    { href: "/about", label: "About", icon: User },
  ];

  const topLinks = [
    { href: "/", label: "Home" },
    { href: "/settings", label: "Settings" },
    { href: "/pricing", label: "Pricing" },
  ];

  return (
    <>
      {/* Desktop Top Menu Bar */}
      <div className="hidden md:block fixed top-0 left-0 right-0 h-14 bg-background/80 backdrop-blur-lg border-b border-border z-40">
        <div className="flex items-center justify-between px-8 h-full">
          <Link href="/" className="text-lg font-bold text-primary hover:text-primary/80 transition-colors">
            <span className="flex items-center gap-2">
              <img src={thundersLogo} alt="Thunders AI" className="w-6 h-6 object-contain" />
              Thunders AI
            </span>
          </Link>
          <nav className="flex items-center gap-8">
            {topLinks.map((link) => {
              const isActive = location === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "text-sm font-medium transition-colors",
                    isActive
                      ? "text-primary"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-background/80 backdrop-blur-lg border-b border-border z-50 flex items-center justify-between px-4">
        <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-emerald-400">
          Thunders AI
        </span>
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 text-muted-foreground hover:text-primary transition-colors"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden fixed inset-0 top-16 bg-background z-40 p-4"
          >
            <nav className="flex flex-col space-y-2">
              {mainLinks.map((link) => {
                const Icon = link.icon;
                const isActive = location === link.href;
                return (
                  <Link 
                    key={link.href} 
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      "flex items-center space-x-3 px-4 py-3 rounded-lg text-lg font-medium transition-all duration-200",
                      isActive 
                        ? "bg-primary/10 text-primary" 
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{link.label}</span>
                  </Link>
                );
              })}
              <div className="my-4 border-t border-border/30" />
              {topLinks.map((link) => {
                const isActive = location === link.href;
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      "flex items-center space-x-3 px-4 py-3 rounded-lg text-lg font-medium transition-all duration-200",
                      isActive 
                        ? "bg-primary/10 text-primary" 
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                    )}
                  >
                    <span>{link.label}</span>
                  </Link>
                );
              })}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex fixed top-14 left-0 bottom-0 w-64 bg-card border-r border-border flex-col z-30">
        <div className="p-6 pt-8">
          <p className="text-xs text-muted-foreground font-medium tracking-wide">
            MENTOR • GUIDE • FRIEND
          </p>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {mainLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location === link.href;
            return (
              <Link 
                key={link.href} 
                href={link.href}
                className={cn(
                  "flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 group relative overflow-hidden",
                  isActive 
                    ? "text-primary bg-primary/10" 
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute left-0 w-1 h-6 bg-primary rounded-full"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  />
                )}
                <Icon className={cn("w-5 h-5 transition-transform group-hover:scale-110", isActive && "text-primary")} />
                <span>{link.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Bottom Menu */}
        <nav className="px-4 py-6 space-y-2 border-t border-border">
          {topLinks.slice(1).map((link) => {
            const Icon = link.label === "Settings" ? Settings : link.label === "Pricing" ? DollarSign : Home;
            const isActive = location === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <Icon className="w-4 h-4" />
                <span>{link.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-6 border-t border-border/50">
          <div className="bg-gradient-to-br from-secondary to-card p-4 rounded-xl border border-border/50">
            <p className="text-xs text-muted-foreground mb-2">Daily Insight</p>
            <p className="text-sm font-medium text-foreground">"Consistency is the key to mastery."</p>
          </div>
        </div>
      </aside>
    </>
  );
}
