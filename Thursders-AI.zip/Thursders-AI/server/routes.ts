import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { processChat } from "./bot";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // === Chat Endpoint ===
  app.post(api.chat.send.path, async (req, res) => {
    try {
      const { message, context } = api.chat.send.input.parse(req.body);
      
      // Process message with our bot logic
      const result = processChat(message, context);
      
      // If the bot says to SAVE_JOURNAL, we do it automatically here
      if (result.action === "SAVE_JOURNAL" && result.data) {
        await storage.createJournal({
          content: result.data.content,
          responses: result.data.responses
        });
      }

      res.json({
        message: result.response,
        action: result.action as any,
        data: result.newContext // We pass newContext back to frontend to store
      });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // === Journal Endpoints ===
  app.get(api.journals.list.path, async (req, res) => {
    const journals = await storage.getJournals();
    res.json(journals);
  });

  app.post(api.journals.create.path, async (req, res) => {
    try {
      const input = api.journals.create.input.parse(req.body);
      const journal = await storage.createJournal(input);
      res.status(201).json(journal);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.journals.delete.path, async (req, res) => {
    await storage.deleteJournal(Number(req.params.id));
    res.status(204).send();
  });

  return httpServer;
}
