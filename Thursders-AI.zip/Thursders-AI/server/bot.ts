
// Structure of our Knowledge Base
export const KNOWLEDGE_BASE = {
  ai_basics: {
    keywords: ["ai", "artificial intelligence", "ml", "machine learning", "basics"],
    content: "Artificial Intelligence (AI) is the simulation of human intelligence processes by machines, especially computer systems. It includes learning (acquisition of information), reasoning (using rules to reach conclusions), and self-correction. Key types include Narrow AI (specialized tasks) and General AI (human-level adaptability).",
  },
  study_tips: {
    keywords: ["study", "learn", "exam", "test", "memory", "focus"],
    content: "Here are effective study techniques:\n1. **Active Recall**: Test yourself instead of just re-reading.\n2. **Spaced Repetition**: Review material at increasing intervals.\n3. **Pomodoro Technique**: Work 25 mins, break 5 mins.\n4. **Feynman Technique**: Teach the concept to someone else (or me!) to verify understanding.",
  },
  productivity: {
    keywords: ["productive", "work", "time", "procrastinate", "procrastination"],
    content: "To boost productivity: \n- **Eat the Frog**: Do the hardest task first thing in the morning.\n- **Time Blocking**: Dedicate specific hours to specific tasks.\n- **Minimize Distractions**: Put your phone away during deep work blocks.",
  },
  mindset: {
    keywords: ["mindset", "growth", "fail", "failure", "success"],
    content: "Adopt a **Growth Mindset**: Believe that your abilities can be developed through dedication and hard work. View challenges as opportunities to learn, not as failures. 'I can't do it' → 'I can't do it YET.'",
  },
  motivation: {
    keywords: ["motivate", "motivation", "tired", "give up", "hard"],
    content: "Motivation follows action, it doesn't precede it. Start with just 5 minutes. Remember why you started. 'Discipline is choosing between what you want now and what you want most.'",
  }
};

export const JOURNAL_QUESTIONS = [
  "What is one new thing you learned today?",
  "What was a challenge you faced, and how did you handle it?",
  "What is your main goal for tomorrow?"
];

export function processChat(message: string, context: any = {}): { response: string, action?: string, newContext?: any, data?: any } {
  const msg = message.toLowerCase();

  // 1. Journaling Mode Logic
  if (context?.mode === 'journaling') {
    const step = context.step || 0;
    const answers = context.answers || [];
    
    // Save current answer
    answers.push(message);

    // If more questions remain
    if (step < JOURNAL_QUESTIONS.length - 1) {
      return {
        response: JOURNAL_QUESTIONS[step + 1],
        newContext: { mode: 'journaling', step: step + 1, answers }
      };
    } else {
      // Finished journaling
      // We return a special action so the frontend (or backend route) knows to save this
      const journalEntry = {
        content: `Journal Entry - ${new Date().toLocaleDateString()}`,
        responses: {
          q1: JOURNAL_QUESTIONS[0], a1: answers[0],
          q2: JOURNAL_QUESTIONS[1], a2: answers[1],
          q3: JOURNAL_QUESTIONS[2], a3: answers[2]
        }
      };
      
      return {
        response: "Great job reflecting today. I've saved your journal entry. Keep building your future!",
        action: "SAVE_JOURNAL",
        data: journalEntry,
        newContext: null // Exit journaling mode
      };
    }
  }

  // 2. Command: Start Journal
  if (msg.includes("start journal") || msg.includes("journaling")) {
    return {
      response: `Let's reflect on your day. ${JOURNAL_QUESTIONS[0]}`,
      newContext: { mode: 'journaling', step: 0, answers: [] },
      action: "START_JOURNAL"
    };
  }

  // 3. Knowledge Base Lookup
  for (const topic of Object.values(KNOWLEDGE_BASE)) {
    if (topic.keywords.some(k => msg.includes(k))) {
      return { response: topic.content };
    }
  }

  // 4. Default / "Thursders AI" Persona Responses
  if (msg.includes("hello") || msg.includes("hi")) {
    return { response: "Hello. I am Thursders AI, your digital mentor. How can I help you build your future today?" };
  }
  
  if (msg.includes("who are you")) {
    return { response: "I am Thursders AI. My goal is to help you think better, learn deeper, and build the future. I run entirely offline, focusing on logic and structured knowledge." };
  }

  return { response: "That's an interesting thought. Could you elaborate? I can also help you learn about AI, productivity, or guide you through a daily journal." };
}
