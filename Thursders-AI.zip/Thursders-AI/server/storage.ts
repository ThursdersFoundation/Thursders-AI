import { db } from "./db";
import {
  journals,
  type InsertJournal,
  type Journal
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Journals
  getJournals(): Promise<Journal[]>;
  createJournal(journal: InsertJournal): Promise<Journal>;
  deleteJournal(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getJournals(): Promise<Journal[]> {
    return await db.select().from(journals).orderBy(desc(journals.createdAt));
  }

  async createJournal(insertJournal: InsertJournal): Promise<Journal> {
    const [journal] = await db.insert(journals).values(insertJournal).returning();
    return journal;
  }

  async deleteJournal(id: number): Promise<void> {
    await db.delete(journals).where(eq(journals.id, id));
  }
}

export const storage = new DatabaseStorage();
