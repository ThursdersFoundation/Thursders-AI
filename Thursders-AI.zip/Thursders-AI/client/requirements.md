## Packages
framer-motion | Smooth animations for chat bubbles and page transitions
react-markdown | Rendering rich text in chat messages
date-fns | Formatting dates for journal entries
clsx | Utility for constructing className strings conditionally (often used with tailwind-merge)
tailwind-merge | Utility for merging Tailwind classes

## Notes
- Dark mode is the default and priority
- Chat interface needs to handle streaming-like UX (even if not streaming)
- Journal entries are stored as JSONB in backend, frontend needs to parse/display them
