import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";

// Define a local message type for UI state
export type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
};

export function useChat() {
  return useMutation({
    mutationFn: async (data: { message: string; context?: any }) => {
      // Validate input using the schema from routes
      const validated = api.chat.send.input.parse(data);
      
      const res = await fetch(api.chat.send.path, {
        method: api.chat.send.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error("Failed to send message");
      }

      // Parse and return the response using the schema
      return api.chat.send.responses[200].parse(await res.json());
    },
  });
}
