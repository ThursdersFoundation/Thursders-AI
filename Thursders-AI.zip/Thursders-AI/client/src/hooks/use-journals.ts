import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertJournal } from "@shared/schema";

// GET /api/journals
export function useJournals() {
  return useQuery({
    queryKey: [api.journals.list.path],
    queryFn: async () => {
      const res = await fetch(api.journals.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch journals");
      return api.journals.list.responses[200].parse(await res.json());
    },
  });
}

// POST /api/journals
export function useCreateJournal() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertJournal) => {
      const validated = api.journals.create.input.parse(data);
      const res = await fetch(api.journals.create.path, {
        method: api.journals.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.journals.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create journal");
      }

      return api.journals.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.journals.list.path] });
    },
  });
}

// DELETE /api/journals/:id
export function useDeleteJournal() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.journals.delete.path, { id });
      const res = await fetch(url, { 
        method: api.journals.delete.method,
        credentials: "include" 
      });

      if (res.status === 404) throw new Error("Journal not found");
      if (!res.ok) throw new Error("Failed to delete journal");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.journals.list.path] });
    },
  });
}
