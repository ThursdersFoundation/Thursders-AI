import { type Journal } from "@shared/schema";
import { format } from "date-fns";
import { Trash2, Quote } from "lucide-react";
import { motion } from "framer-motion";
import { useDeleteJournal } from "@/hooks/use-journals";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface JournalCardProps {
  journal: Journal;
  index: number;
}

export function JournalCard({ journal, index }: JournalCardProps) {
  const { mutate: deleteJournal, isPending } = useDeleteJournal();
  const { toast } = useToast();

  const handleDelete = () => {
    deleteJournal(journal.id, {
      onSuccess: () => {
        toast({ title: "Journal deleted", description: "Your entry has been removed." });
      },
      onError: () => {
        toast({ title: "Error", description: "Could not delete entry.", variant: "destructive" });
      }
    });
  };

  // Parse responses if it's a JSON object string, or just use content
  let displayContent = journal.content;
  
  // If content is very short, try to use responses if available to show more context
  if (journal.content.length < 50 && journal.responses && typeof journal.responses === 'object') {
     // This logic depends on how you structure responses. Assuming a simple Q&A map.
     // For now, we mainly rely on the summary text in 'content' field.
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="group relative bg-card border border-border/50 rounded-2xl p-6 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5"
    >
      <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <button 
              className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full transition-colors"
              disabled={isPending}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </AlertDialogTrigger>
          <AlertDialogContent className="bg-card border-border">
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Journal Entry?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete your journal entry.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      <div className="flex items-start space-x-4">
        <div className="bg-secondary/50 p-3 rounded-xl">
          <Quote className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1">
          <div className="flex items-center space-x-2 text-xs font-medium text-muted-foreground mb-3">
            <span>{format(new Date(journal.createdAt || new Date()), "MMMM d, yyyy")}</span>
            <span>•</span>
            <span>{format(new Date(journal.createdAt || new Date()), "h:mm a")}</span>
          </div>
          <p className="text-foreground/90 leading-relaxed text-sm md:text-base whitespace-pre-wrap">
            {displayContent}
          </p>
          
          {/* Optional: if there are specific structured responses, you could render them here */}
          {/* 
          {journal.responses && (
            <div className="mt-4 pt-4 border-t border-border/30">
              <span className="text-xs font-bold text-primary uppercase tracking-wider">Reflection</span>
            </div>
          )}
          */}
        </div>
      </div>
    </motion.div>
  );
}
