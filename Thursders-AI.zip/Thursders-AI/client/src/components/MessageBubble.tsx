import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { Bot, User } from "lucide-react";

interface MessageBubbleProps {
  role: "user" | "assistant";
  content: string;
}

export function MessageBubble({ role, content }: MessageBubbleProps) {
  const isUser = role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={cn(
        "flex w-full mb-6",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      <div className={cn("flex max-w-[85%] md:max-w-[75%]", isUser ? "flex-row-reverse" : "flex-row")}>
        {/* Avatar */}
        <div className={cn(
          "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mt-1 shadow-lg",
          isUser 
            ? "ml-3 bg-secondary text-white" 
            : "mr-3 bg-gradient-to-br from-primary to-purple-500 text-white"
        )}>
          {isUser ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
        </div>

        {/* Bubble */}
        <div className={cn(
          "px-5 py-3 rounded-2xl shadow-md text-sm leading-relaxed",
          isUser
            ? "bg-secondary text-secondary-foreground rounded-tr-sm"
            : "glass-panel text-foreground rounded-tl-sm border border-white/5"
        )}>
          <ReactMarkdown 
            className="prose prose-invert prose-sm max-w-none"
            components={{
              p: ({children}) => <p className="mb-2 last:mb-0">{children}</p>,
              ul: ({children}) => <ul className="list-disc pl-4 mb-2">{children}</ul>,
              ol: ({children}) => <ol className="list-decimal pl-4 mb-2">{children}</ol>,
              code: ({children}) => <code className="bg-black/30 px-1 py-0.5 rounded text-xs font-mono">{children}</code>
            }}
          >
            {content}
          </ReactMarkdown>
        </div>
      </div>
    </motion.div>
  );
}
