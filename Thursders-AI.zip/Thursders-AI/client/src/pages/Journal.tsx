import { useJournals } from "@/hooks/use-journals";
import { JournalCard } from "@/components/JournalCard";
import { Book, PenTool, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Journal() {
  const { data: journals, isLoading, error } = useJournals();

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-full items-center justify-center text-destructive">
        Error loading journals.
      </div>
    );
  }

  const isEmpty = !journals || journals.length === 0;

  return (
    <div className="p-4 md:p-8 lg:p-12 max-w-5xl mx-auto w-full h-full overflow-y-auto">
      <div className="mb-8 md:mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-gradient-primary mb-3">
          Your Reflections
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl">
          A collection of your thoughts, learnings, and goals. Review your progress and clarify your mind.
        </p>
      </div>

      {isEmpty ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-border rounded-3xl bg-card/30"
        >
          <div className="bg-secondary/50 p-6 rounded-full mb-6">
            <PenTool className="w-12 h-12 text-primary/50" />
          </div>
          <h3 className="text-xl font-semibold mb-2">No Entries Yet</h3>
          <p className="text-muted-foreground max-w-sm mb-6">
            Start a conversation with the AI by typing "start journal" to create your first entry.
          </p>
          <div className="bg-primary/10 text-primary px-4 py-2 rounded-lg text-sm font-medium">
            Go to Chat to begin
          </div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 gap-6 pb-20">
          {journals.map((journal, index) => (
            <JournalCard key={journal.id} journal={journal} index={index} />
          ))}
        </div>
      )}
    </div>
  );
}
