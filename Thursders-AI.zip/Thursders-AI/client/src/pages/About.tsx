import { motion } from "framer-motion";
import { Brain, Zap, Target, Heart } from "lucide-react";

export default function About() {
  const features = [
    {
      icon: Brain,
      title: "Adaptive Learning",
      description: "Explains concepts based on your level, helping you understand complex topics simply."
    },
    {
      icon: Target,
      title: "Goal Oriented",
      description: "Keeps you focused on your objectives with accountability and structured planning."
    },
    {
      icon: Heart,
      title: "Reflective Practice",
      description: "Encourages daily journaling and mindfulness to build mental clarity and resilience."
    },
    {
      icon: Zap,
      title: "Instant Guidance",
      description: "Always available to answer questions, brainstorm ideas, and unstuck your thinking."
    }
  ];

  return (
    <div className="p-4 md:p-8 lg:p-12 max-w-5xl mx-auto w-full h-full overflow-y-auto pb-20">
      <div className="text-center mb-16 space-y-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-4 tracking-tight">
            <span className="text-gradient-primary">Thursders AI</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
            Your personal digital mentor for learning, thinking, and growing.
          </p>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
        {features.map((feature, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-card border border-border/50 p-8 rounded-2xl hover:border-primary/30 transition-colors group"
          >
            <div className="bg-secondary/50 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
              <feature.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
            <p className="text-muted-foreground leading-relaxed">
              {feature.description}
            </p>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="bg-gradient-to-br from-primary/10 to-purple-500/10 border border-primary/20 rounded-3xl p-8 md:p-12 text-center"
      >
        <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to upgrade your mind?</h2>
        <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
          Start a conversation today. Ask about a complex topic, set a goal, or just reflect on your day.
        </p>
        <div className="inline-flex items-center justify-center px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/25">
          Start Chatting
        </div>
      </motion.div>
    </div>
  );
}
