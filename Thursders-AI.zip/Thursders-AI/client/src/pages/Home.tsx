import { useState, useRef, useEffect } from "react";
import { Send, Sparkles } from "lucide-react";
import { Message, useChat } from "@/hooks/use-chat";
import { MessageBubble } from "@/components/MessageBubble";
import { nanoid } from "nanoid";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useCreateJournal } from "@/hooks/use-journals";

export default function Home() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hello. I am Thursders AI. I'm here to help you learn, reflect, and grow. What's on your mind today?",
      timestamp: Date.now(),
    },
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { mutate: sendMessage, isPending } = useChat();
  const { mutate: saveJournal } = useCreateJournal();
  const { toast } = useToast();

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isPending) return;

    const userMsg: Message = {
      id: nanoid(),
      role: "user",
      content: input,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");

    sendMessage(
      { message: userMsg.content },
      {
        onSuccess: (data) => {
          const aiMsg: Message = {
            id: nanoid(),
            role: "assistant",
            content: data.message,
            timestamp: Date.now(),
          };
          setMessages((prev) => [...prev, aiMsg]);

          // Handle special actions
          if (data.action === "SAVE_JOURNAL" && data.data) {
             // Backend parsed a journal entry - save it automatically or ask user?
             // For seamless experience, we can save it and notify.
             saveJournal({
               content: data.data.summary || "Journal Entry",
               responses: data.data,
             }, {
               onSuccess: () => {
                 toast({ 
                   title: "Journal Saved", 
                   description: "Your reflection has been added to your journal.",
                 });
               }
             });
          }
        },
        onError: () => {
          toast({
            title: "Error",
            description: "Failed to get a response. Please try again.",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="flex flex-col h-full relative">
      {/* Header Area */}
      <div className="sticky top-0 z-10 p-6 bg-background/80 backdrop-blur-md border-b border-white/5 md:hidden">
        {/* Mobile header handled in Navigation layout wrapper, but we keep this for spacing if needed */}
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
        <div className="max-w-3xl mx-auto w-full">
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <MessageBubble key={msg.id} role={msg.role} content={msg.content} />
            ))}
          </AnimatePresence>
          
          {isPending && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="flex items-center space-x-2 text-muted-foreground ml-12 text-sm"
            >
              <Sparkles className="w-4 h-4 animate-pulse text-primary" />
              <span>Thinking...</span>
            </motion.div>
          )}
          <div ref={messagesEndRef} className="h-4" />
        </div>
      </div>

      {/* Input Area */}
      <div className="p-4 md:p-6 bg-background/80 backdrop-blur-lg border-t border-white/5">
        <div className="max-w-3xl mx-auto w-full relative">
          <form onSubmit={handleSubmit} className="relative group">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question, start a journal, or seek advice..."
              className="w-full bg-secondary/50 border border-border rounded-xl px-5 py-4 pr-14 text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all duration-300 shadow-lg shadow-black/20"
              disabled={isPending}
            />
            <button
              type="submit"
              disabled={!input.trim() || isPending}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-md shadow-primary/25 hover:shadow-lg hover:shadow-primary/30"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <p className="text-center text-xs text-muted-foreground mt-3 font-medium opacity-60">
            Thursders AI can make mistakes. Consider checking important information.
          </p>
        </div>
      </div>
    </div>
  );
}
