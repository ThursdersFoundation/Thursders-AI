import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const journals = pgTable("journals", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(), // Summary or full text
  responses: jsonb("responses").notNull(), // JSON object with Q&A
  createdAt: timestamp("created_at").defaultNow(),
});

// === BASE SCHEMAS ===
export const insertJournalSchema = createInsertSchema(journals).omit({ id: true, createdAt: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Journal = typeof journals.$inferSelect;
export type InsertJournal = z.infer<typeof insertJournalSchema>;

export type ChatRequest = {
  message: string;
  context?: any; // To handle conversation state like "journaling mode"
};

export type ChatResponse = {
  message: string;
  action?: "NONE" | "START_JOURNAL" | "SAVE_JOURNAL";
  data?: any;
};
